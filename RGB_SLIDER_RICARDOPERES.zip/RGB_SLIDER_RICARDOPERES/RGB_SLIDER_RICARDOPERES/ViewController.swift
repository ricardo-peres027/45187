//
//  ViewController.swift
//  RGB_SLIDER_RICARDOPERES
//
//  Created by Alunos_Istec on 24/05/2019.
//  Copyright © 2019 Ricardo Peres. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    var vw1:UIView?
    var lbl1:UILabel?
    var redslider,greenslider,blueslider,alphaslider:UISlider?
    
    lazy var arr:[UIView?] = [vw1, lbl1, redslider, greenslider, blueslider, alphaslider]
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        //labels
        self.lbl1 = UILabel(frame: CGRect(x: 38, y: 380, width: 300, height: 50))
        self.lbl1?.textColor = UIColor.black
        self.lbl1?.text = "R: 0.0 G: 0.0 B: 0.0 A: 255.0"
        self.vw1 = UIView(frame: CGRect(x: 88, y: 150, width: 200, height: 200))
        self.vw1?.backgroundColor = UIColor.black
        
        //red
        self.redslider = UISlider(frame: CGRect(x: 35, y: 400, width: 300, height: 100))
        self.redslider?.addTarget(self, action: #selector(changeColor), for: .valueChanged)
        self.redslider?.tintColor = UIColor.red
        
        //green
        self.greenslider = UISlider(frame: CGRect(x: 35, y: 450, width: 300, height: 100))
        self.greenslider?.tintColor = UIColor.green
        self.greenslider?.addTarget(self, action: #selector(changeColor), for: .valueChanged)
        
        //blue
        self.blueslider = UISlider(frame: CGRect(x: 35, y: 500, width: 300, height: 100))
        self.blueslider?.tintColor = UIColor.blue
        self.blueslider?.addTarget(self, action: #selector(changeColor), for: .valueChanged)
        
        //alpha
        self.alphaslider?.addTarget(self, action: #selector(changeColor), for: .valueChanged)
        self.alphaslider?.value = 1
        self.alphaslider?.tintColor = UIColor.black
        self.alphaslider = UISlider(frame: CGRect(x: 35, y: 550, width: 300, height: 100))
        
        for vista in arr
        {
            if let v = vista
            {
                self.view.addSubview(v)
            }
        }
    }
    
    @objc
    func changeColor()
    {
        
        let red = CGFloat((redslider?.value)!)
        let green = CGFloat((greenslider?.value)!)
        let blue = CGFloat((blueslider?.value)!)
        let alpha = CGFloat((alphaslider?.value)!)
        self.lbl1?.text = "R: \(round(redslider!.value*255)) G: \(round(greenslider!.value*255)) B: \(round(blueslider!.value*255)) A: \(round(alphaslider!.value*255))"
        self.vw1?.backgroundColor = UIColor(red: red, green: green, blue: blue, alpha: alpha)
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}

